/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package web;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Misty
 */
public class MenscollectionController implements Initializable {

    @FXML
    private TextField nameid;
    @FXML
    private CheckBox cshirt;
    @FXML
    private CheckBox tshirt;
    @FXML
    private CheckBox dshirt;
    @FXML
    private CheckBox cpunjabi;
    @FXML
    private CheckBox shoes;
    @FXML
    private CheckBox watch;
    @FXML
    private CheckBox wleather;
    @FXML
    private CheckBox wnew;
    @FXML
    private ComboBox<String> comobid;
    @FXML
    private TextArea orderArea;

    /**
     * Initializes the controller class.
     * @param url
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        comobid.getItems().add("Bkash");
        comobid.getItems().add("Rocket");
        comobid.getItems().add("Cash on Delivery");
       
  
    }    

    @FXML
    private void submitId(ActionEvent event) {
        
        String name = nameid.getText();
        String payment = comobid.getValue();
        
        String item="";
        if(cshirt.isSelected())
        {
            item = item + "Cotton shirt" ;
        }
        if(tshirt.isSelected())
        {
            item = item + "T-shirt" ;
        }
        if(dshirt.isSelected())
        {
            item = item + "Designer Shirt" ;
        }
        if(cpunjabi.isSelected())
        {
            item = item + "Cotton Punjabi" ;
        }
         if(shoes.isSelected())
        {
            item = item + " Shoes" ;
        }
         if(wleather.isSelected())
        {
            item = item + "Leather wallet" ;
        }
         if(wnew.isSelected())
        {
            item = item + "New Designer Wallet" ;
        }
        
         
          String str =  name +","+payment+","+item  + ",";
        
        
        File f = null;
        FileWriter fw = null;
        try {
            f = new File("OrderedItem.txt");
      
            if(f.exists()) fw = new FileWriter(f,true);
            else fw = new FileWriter(f);
           
            
            fw.write(str);
            
            
        } catch (IOException ex) {
            
        } 
        
        finally {
            try {
                if(fw != null) fw.close();
            } catch (IOException ex) {
            }
        }
        
    }

    @FXML
    private void backToHome(ActionEvent event) throws IOException {
        Parent parent = FXMLLoader.load(getClass().getResource("login.fxml"));
        Scene scene = new Scene(parent);

        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

        window.setScene(scene);
        window.show();
        
    }

    @FXML
    private void viewOrdersm(ActionEvent event) throws FileNotFoundException {
        
        File f = new File("OrderedItem.txt");
        
        Scanner scan = new Scanner(f);
        String[] A = null;
        String s = " ";
        
        while(scan.hasNextLine())
        {
            A = scan.nextLine().split(",");
        }

        
        
        for(int i=0;i<A.length;i+=3)
        {
            int counter = i;
            
            
                s = s + A[counter] + "," + A[counter+1] + "," + A[counter+2] + "\n";
            
          orderArea.setText(s);      
     
        }
    }
    
}
