/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package web;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Misty
 */
public class SignUpController implements Initializable {

    @FXML
    private TextField userName;
    @FXML
    private TextField emailId;
    @FXML
    private PasswordField passwordId;
    @FXML
    private ComboBox<String> comboUserId;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        comboUserId.getItems().add("Client");
        comboUserId.getItems().add("Employee");
        comboUserId.getItems().add("Delivery man");
      
    }    

    @FXML
    private void submitId(ActionEvent event) throws IOException {
      String user = comboUserId.getValue();
        
        if("Client".equals(user))
        {
            Parent parent = FXMLLoader.load(getClass().getResource("ClientPage.fxml"));
        Scene scene = new Scene(parent);

        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

        window.setScene(scene);
        window.show();
        }
       if("Employee".equals(user))
        {
            Parent parent = FXMLLoader.load(getClass().getResource("EmployeePage.fxml"));
        Scene scene = new Scene(parent);

        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

        window.setScene(scene);
        window.show();
        }
        
        
    }

    @FXML
    private void backToHome(ActionEvent event) throws IOException {
        Parent parent = FXMLLoader.load(getClass().getResource("login.fxml"));
        Scene scene = new Scene(parent);

        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

        window.setScene(scene);
        window.show();
        
    }

    
}
