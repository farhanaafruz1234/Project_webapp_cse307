/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package web;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Misty
 */
public class WomenscollectionController implements Initializable {

    @FXML
    private CheckBox CottonKurti;
    @FXML
    private CheckBox OrganzaKurti;
    @FXML
    private CheckBox Bag;
    @FXML
    private CheckBox Shoes;
    @FXML
    private CheckBox CottonDress;
    @FXML
    private CheckBox bDress;
    @FXML
    private CheckBox BabyShoes;
    @FXML
    private ComboBox<String> comobid;
    @FXML
    private TextField nameid;
    @FXML
    private TextArea orderArea;

    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        comobid.getItems().add("Bkash");
        comobid.getItems().add("Rocket");
        comobid.getItems().add("Cash on Delivery");
        
    }    

    @FXML
    private void SubmitId(ActionEvent event) {
        String name = nameid.getText();
        String payment = comobid.getValue();
        
        String item="";
        if(CottonKurti.isSelected())
        {
            item = item + "Cotton Kurti" ;
        }
        if(OrganzaKurti.isSelected())
        {
            item = item + "Organza Kurti" ;
        }
        if(Bag.isSelected())
        {
            item = item + "Hand Bag " ;
        }
        if(Shoes.isSelected())
        {
            item = item + "Shoes " ;
        }
         if(Shoes.isSelected())
        {
            item = item + " Shoes" ;
        }
         if(CottonDress.isSelected())
        {
            item = item + "Cotton Baby Dress " ;
        }
         if(bDress.isSelected())
        {
            item = item + "1-2 Years Baby Dress" ;
        }
         if(BabyShoes.isSelected())
        {
            item = item + " Baby Shoes" ;
        }
        
         
          String str =  name +","+ payment+","+item  + ",";
        
        

        File f = null;
        FileWriter fw = null;
        try {
            f = new File("Womenandkidscart.txt");
      
            if(f.exists()) fw = new FileWriter(f,true);
            else fw = new FileWriter(f);
           
            
            fw.write(str);
            
          
        } catch (IOException ex) {
            
            
        } 
        
        finally {
            try {
                if(fw != null) fw.close();
            } catch (IOException ex) {
            }
        }
        
    }

    @FXML
    private void backToHome(ActionEvent event) throws IOException {
        Parent parent = FXMLLoader.load(getClass().getResource("login.fxml"));
        Scene scene = new Scene(parent);

        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

        window.setScene(scene);
        window.show();
        
    }

    @FXML
    private void viewOrdersw(ActionEvent event) throws FileNotFoundException {
        
         File f = new File("Womenandkidscart.txt");
        
        Scanner scan = new Scanner(f);
        String[] A = null;
        String s = " ";
        
        while(scan.hasNextLine())
        {
            A = scan.nextLine().split(",");
        }

        
        
        for(int i=0;i<A.length;i+=3)
        {
            int counter = i;
            
            
                s = s + A[counter] + "," + A[counter+1] + "," + A[counter+2] + "\n";
            
          orderArea.setText(s);      
     
        }
    }
 }


    

